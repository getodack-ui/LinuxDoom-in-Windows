#ifndef COMPAT_UNISTD_H
#define COMPAT_UNISTD_H
#include <io.h>
#include <fcntl.h>
#include <direct.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifndef R_OK
#define R_OK 4
#endif
#endif
