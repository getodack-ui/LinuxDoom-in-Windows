/* Force-included into every source file.
   Keep it minimal:
   - never include <windows.h> here (its "boolean" clashes with Doom's enum)
   - never include <io.h> here (it declares open()/close(), which clash with
     the door-state enum values in p_spec.h); the few files that need POSIX
     file I/O get it through compat/unistd.h */
#ifndef WIN_COMPAT_H
#define WIN_COMPAT_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <malloc.h>
#ifdef _MSC_VER
#define strcasecmp  _stricmp
#define strncasecmp _strnicmp
#define alloca      _alloca
#endif
#endif
