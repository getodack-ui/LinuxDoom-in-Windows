// Win32 replacement for linuxdoom i_net.c: single player / local only.
#include <stdlib.h>
#include <string.h>

#include "i_system.h"
#include "d_event.h"
#include "d_net.h"
#include "m_argv.h"
#include "doomstat.h"
#include "i_net.h"

void I_NetCmd(void)
{
    // no network transport in this port
}

void I_InitNetwork(void)
{
    int i;

    doomcom = malloc(sizeof(*doomcom));
    memset(doomcom, 0, sizeof(*doomcom));

    i = M_CheckParm("-dup");
    if (i && i < myargc - 1)
    {
        doomcom->ticdup = myargv[i + 1][0] - '0';
        if (doomcom->ticdup < 1) doomcom->ticdup = 1;
        if (doomcom->ticdup > 9) doomcom->ticdup = 9;
    }
    else
        doomcom->ticdup = 1;

    doomcom->extratics = M_CheckParm("-extratic") ? 1 : 0;

    if (M_CheckParm("-net"))
        I_Error("Network play is not supported in this Windows port.");

    netgame = false;
    doomcom->id = DOOMCOM_ID;
    doomcom->numplayers = doomcom->numnodes = 1;
    doomcom->deathmatch = false;
    doomcom->consoleplayer = 0;
}
