// Win32 replacement for linuxdoom i_system.c
#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <mmsystem.h>      // timeBeginPeriod (excluded by WIN32_LEAN_AND_MEAN)

#undef MAXCHAR
#undef MAXSHORT
#undef MAXINT
#undef MAXLONG
#undef MINCHAR
#undef MINSHORT
#undef MININT
#undef MINLONG
#ifdef _MSC_VER
#pragma comment(lib, "winmm.lib")
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "doomdef.h"
#include "m_misc.h"
#include "i_video.h"
#include "i_sound.h"
#include "d_net.h"
#include "g_game.h"
#include "i_system.h"

extern void I_ShutdownMusic(void);
extern boolean demorecording;

int mb_used = 6;

void I_Tactile(int on, int off, int total)
{
    on = off = total = 0;
}

ticcmd_t emptycmd;
ticcmd_t* I_BaseTiccmd(void)
{
    return &emptycmd;
}

int I_GetHeapSize(void)
{
    return mb_used * 1024 * 1024;
}

byte* I_ZoneBase(int* size)
{
    *size = mb_used * 1024 * 1024;
    return (byte*)malloc(*size);
}

//
// I_GetTime: time in 1/35th second tics
//
int I_GetTime(void)
{
    static LARGE_INTEGER freq;
    static LARGE_INTEGER base;
    LARGE_INTEGER now;

    if (!freq.QuadPart)
    {
        QueryPerformanceFrequency(&freq);
        QueryPerformanceCounter(&base);
    }
    QueryPerformanceCounter(&now);
    return (int)(((now.QuadPart - base.QuadPart) * TICRATE) / freq.QuadPart);
}

// Called while waiting for the next tic, so we do not burn a whole core.
void I_Yield(void)
{
    Sleep(1);
}

void I_Init(void)
{
    timeBeginPeriod(1);
    I_InitSound();
}

void I_Quit(void)
{
    D_QuitNetGame();
    I_ShutdownSound();
    I_ShutdownMusic();
    M_SaveDefaults();
    I_ShutdownGraphics();
    timeEndPeriod(1);
    exit(0);
}

void I_WaitVBL(int count)
{
    Sleep((count * 1000) / 70);
}

void I_BeginRead(void) { }
void I_EndRead(void) { }

byte* I_AllocLow(int length)
{
    byte* mem = (byte*)malloc(length);
    memset(mem, 0, length);
    return mem;
}

void I_Error(char* error, ...)
{
    va_list argptr;
    char    msg[1024];

    va_start(argptr, error);
    vsnprintf(msg, sizeof(msg), error, argptr);
    va_end(argptr);

    fprintf(stderr, "Error: %s\n", msg);
    fflush(stderr);

    if (demorecording)
        G_CheckDemoStatus();

    D_QuitNetGame();
    I_ShutdownGraphics();

    MessageBoxA(NULL, msg, "DOOM - Error", MB_OK | MB_ICONERROR);
    exit(-1);
}
