// Win32 / GDI replacement for linuxdoom i_video.c
//
// Renders the 320x200 8-bit screen through a palette lookup into a 32-bit DIB
// and stretches it (nearest neighbour, 4:3 aspect) into the window.
// Keyboard/mouse come from window messages.

#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>

// windows.h defines its own MAXCHAR/MAXSHORT/...; Doom's doomtype.h wants its own.
#undef MAXCHAR
#undef MAXSHORT
#undef MAXINT
#undef MAXLONG
#undef MINCHAR
#undef MINSHORT
#undef MININT
#undef MINLONG

#include <stdlib.h>
#include <string.h>

#include "doomdef.h"
#include "doomstat.h"
#include "d_event.h"
#include "d_main.h"
#include "i_system.h"
#include "i_video.h"
#include "m_argv.h"
#include "m_menu.h"
#include "v_video.h"

extern int usemouse;

#define WINDOW_CLASS "DoomWinClass"
#define ASPECT_W 4
#define ASPECT_H 3

static HWND       hwnd;
static HINSTANCE  hinst;
static int        scale = 3;            // initial client size = (320*scale) x (240*scale)
static int        fullscreen;
static int        wantfullscreen;
static int        window_active;
static int        quit_requested;
static int        cursor_grabbed;
static int        mousebuttons;
static WINDOWPLACEMENT saved_placement;

static unsigned int  pal32[256];
static unsigned int* pixels;
static BITMAPINFO    bmi;
static byte          keystate[256];

//
// Keys
//
static int xlatekey(WPARAM vk)
{
    switch (vk)
    {
      case VK_LEFT:     return KEY_LEFTARROW;
      case VK_RIGHT:    return KEY_RIGHTARROW;
      case VK_DOWN:     return KEY_DOWNARROW;
      case VK_UP:       return KEY_UPARROW;
      case VK_ESCAPE:   return KEY_ESCAPE;
      case VK_RETURN:   return KEY_ENTER;
      case VK_TAB:      return KEY_TAB;
      case VK_F1:       return KEY_F1;
      case VK_F2:       return KEY_F2;
      case VK_F3:       return KEY_F3;
      case VK_F4:       return KEY_F4;
      case VK_F5:       return KEY_F5;
      case VK_F6:       return KEY_F6;
      case VK_F7:       return KEY_F7;
      case VK_F8:       return KEY_F8;
      case VK_F9:       return KEY_F9;
      case VK_F10:      return KEY_F10;
      case VK_F11:      return KEY_F11;
      case VK_F12:      return KEY_F12;
      case VK_BACK:
      case VK_DELETE:   return KEY_BACKSPACE;
      case VK_PAUSE:    return KEY_PAUSE;
      case VK_OEM_PLUS:
      case VK_ADD:      return KEY_EQUALS;
      case VK_OEM_MINUS:
      case VK_SUBTRACT: return KEY_MINUS;
      case VK_SHIFT:    return KEY_RSHIFT;
      case VK_CONTROL:  return KEY_RCTRL;
      case VK_MENU:     return KEY_RALT;
      case VK_SPACE:    return ' ';
      case VK_OEM_COMMA:  return ',';
      case VK_OEM_PERIOD: return '.';
      case VK_OEM_1:    return ';';
      case VK_OEM_2:    return '/';
      case VK_OEM_3:    return '`';
      case VK_OEM_4:    return '[';
      case VK_OEM_5:    return '\\';
      case VK_OEM_6:    return ']';
      case VK_OEM_7:    return '\'';
    }
    if (vk >= 'A' && vk <= 'Z') return (int)vk - 'A' + 'a';
    if (vk >= '0' && vk <= '9') return (int)vk;
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9) return (int)vk - VK_NUMPAD0 + '0';
    return 0;
}

static void PostKey(int key, int down)
{
    event_t ev;

    if (!key)
        return;
    if (down == keystate[key & 255] && !down)
        return;                         // key-up for a key we never saw go down
    keystate[key & 255] = (byte)down;

    ev.type = down ? ev_keydown : ev_keyup;
    ev.data1 = key;
    ev.data2 = ev.data3 = 0;
    D_PostEvent(&ev);
}

static void ReleaseAllKeys(void)
{
    int i;
    for (i = 0; i < 256; i++)
        if (keystate[i])
            PostKey(i, 0);
}

//
// Mouse
//
static void PostMouse(int dx, int dy)
{
    event_t ev;

    ev.type = ev_mouse;
    ev.data1 = mousebuttons;
    ev.data2 = dx << 2;
    ev.data3 = -(dy << 2);
    D_PostEvent(&ev);
}

static void GetClientCenter(POINT* c, RECT* screenrc)
{
    RECT  rc;
    POINT tl, br;

    GetClientRect(hwnd, &rc);
    tl.x = rc.left;  tl.y = rc.top;
    br.x = rc.right; br.y = rc.bottom;
    ClientToScreen(hwnd, &tl);
    ClientToScreen(hwnd, &br);
    screenrc->left = tl.x;  screenrc->top = tl.y;
    screenrc->right = br.x; screenrc->bottom = br.y;
    c->x = (tl.x + br.x) / 2;
    c->y = (tl.y + br.y) / 2;
}

static void GrabCursor(void)
{
    POINT c;
    RECT  rc;

    if (cursor_grabbed)
        return;
    GetClientCenter(&c, &rc);
    ClipCursor(&rc);
    SetCursorPos(c.x, c.y);
    ShowCursor(FALSE);
    cursor_grabbed = 1;
    if (mousebuttons)
        PostMouse(0, 0);                // sync button state
}

static void UngrabCursor(void)
{
    if (!cursor_grabbed)
        return;
    ClipCursor(NULL);
    ShowCursor(TRUE);
    cursor_grabbed = 0;
    if (mousebuttons)
        PostMouse(0, 0);
}

static void UpdateMouse(void)
{
    int want = window_active && usemouse && gamestate == GS_LEVEL && !menuactive;

    if (want && !cursor_grabbed)
        GrabCursor();
    else if (!want && cursor_grabbed)
        UngrabCursor();

    if (cursor_grabbed)
    {
        POINT p, c;
        RECT  rc;

        GetCursorPos(&p);
        GetClientCenter(&c, &rc);
        if (p.x != c.x || p.y != c.y)
        {
            SetCursorPos(c.x, c.y);
            PostMouse(p.x - c.x, p.y - c.y);
        }
    }
}

static void MouseButton(int bit, int down)
{
    if (down) mousebuttons |= bit; else mousebuttons &= ~bit;
    if (cursor_grabbed)
        PostMouse(0, 0);
}

//
// Drawing
//
static void Present(HDC hdc)
{
    RECT rc;
    int  cw, ch, dw, dh, dx, dy;

    if (!pixels)
        return;

    GetClientRect(hwnd, &rc);
    cw = rc.right - rc.left;
    ch = rc.bottom - rc.top;
    if (cw <= 0 || ch <= 0)
        return;

    // largest 4:3 rectangle that fits
    if (cw * ASPECT_H >= ch * ASPECT_W) { dh = ch; dw = ch * ASPECT_W / ASPECT_H; }
    else                                { dw = cw; dh = cw * ASPECT_H / ASPECT_W; }
    dx = (cw - dw) / 2;
    dy = (ch - dh) / 2;

    if (dx > 0 || dy > 0)
    {
        HBRUSH black = (HBRUSH)GetStockObject(BLACK_BRUSH);
        RECT   r;
        if (dx > 0)
        {
            r.left = 0; r.top = 0; r.right = dx; r.bottom = ch;          FillRect(hdc, &r, black);
            r.left = dx + dw; r.right = cw;                              FillRect(hdc, &r, black);
        }
        if (dy > 0)
        {
            r.left = 0; r.top = 0; r.right = cw; r.bottom = dy;         FillRect(hdc, &r, black);
            r.top = dy + dh; r.bottom = ch;                              FillRect(hdc, &r, black);
        }
    }

    SetStretchBltMode(hdc, COLORONCOLOR);
    StretchDIBits(hdc, dx, dy, dw, dh,
                  0, 0, SCREENWIDTH, SCREENHEIGHT,
                  pixels, &bmi, DIB_RGB_COLORS, SRCCOPY);
}

static void ToggleFullscreen(void)
{
    if (!fullscreen)
    {
        MONITORINFO mi;
        mi.cbSize = sizeof(mi);
        saved_placement.length = sizeof(saved_placement);
        GetWindowPlacement(hwnd, &saved_placement);
        GetMonitorInfo(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &mi);
        SetWindowLongPtr(hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowPos(hwnd, HWND_TOP,
                     mi.rcMonitor.left, mi.rcMonitor.top,
                     mi.rcMonitor.right - mi.rcMonitor.left,
                     mi.rcMonitor.bottom - mi.rcMonitor.top,
                     SWP_FRAMECHANGED | SWP_SHOWWINDOW);
        fullscreen = 1;
    }
    else
    {
        SetWindowLongPtr(hwnd, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
        SetWindowPlacement(hwnd, &saved_placement);
        SetWindowPos(hwnd, NULL, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
        fullscreen = 0;
    }
    if (cursor_grabbed)
    {
        UngrabCursor();                 // re-grabbed with the new client rect next tic
    }
}

static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg)
    {
      case WM_CLOSE:
        quit_requested = 1;
        return 0;

      case WM_ERASEBKGND:
        return 1;

      case WM_PAINT:
      {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(h, &ps);
        Present(hdc);
        EndPaint(h, &ps);
        return 0;
      }

      case WM_ACTIVATE:
        window_active = (LOWORD(wp) != WA_INACTIVE);
        if (!window_active)
        {
            ReleaseAllKeys();
            UngrabCursor();
        }
        return 0;

      case WM_SETCURSOR:
        if (cursor_grabbed && LOWORD(lp) == HTCLIENT)
        {
            SetCursor(NULL);
            return TRUE;
        }
        break;

      case WM_SYSCOMMAND:
        if ((wp & 0xFFF0) == SC_KEYMENU)
            return 0;                   // do not let Alt/F10 open the system menu
        break;

      case WM_SYSKEYDOWN:
        if (wp == VK_F4)
            break;                      // Alt+F4 -> close
        if (wp == VK_RETURN)
        {
            if (!(lp & (1 << 30)))      // ignore auto-repeat
                ToggleFullscreen();
            return 0;
        }
        /* fall through */
      case WM_KEYDOWN:
        PostKey(xlatekey(wp), 1);
        return 0;

      case WM_SYSKEYUP:
      case WM_KEYUP:
        PostKey(xlatekey(wp), 0);
        return 0;

      case WM_LBUTTONDOWN: MouseButton(1, 1); return 0;
      case WM_LBUTTONUP:   MouseButton(1, 0); return 0;
      case WM_RBUTTONDOWN: MouseButton(2, 1); return 0;
      case WM_RBUTTONUP:   MouseButton(2, 0); return 0;
      case WM_MBUTTONDOWN: MouseButton(4, 1); return 0;
      case WM_MBUTTONUP:   MouseButton(4, 0); return 0;
    }
    return DefWindowProc(h, msg, wp, lp);
}

//
// Doom video interface
//
void I_ShutdownGraphics(void)
{
    UngrabCursor();
    if (hwnd)
    {
        DestroyWindow(hwnd);
        hwnd = NULL;
    }
    free(pixels);
    pixels = NULL;
}

void I_StartFrame(void)
{
}

void I_StartTic(void)
{
    MSG msg;

    if (!hwnd)
        return;

    while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    if (quit_requested)
        I_Quit();

    UpdateMouse();
}

void I_UpdateNoBlit(void)
{
}

void I_FinishUpdate(void)
{
    int   i;
    byte* src;
    HDC   hdc;

    if (!hwnd)
        return;

    if (devparm)
    {
        static int lasttic;
        int tics = I_GetTime() - lasttic;
        lasttic = I_GetTime();
        if (tics > 20) tics = 20;
        for (i = 0; i < tics * 2; i += 2)
            screens[0][(SCREENHEIGHT - 1) * SCREENWIDTH + i] = 0xff;
        for (; i < 20 * 2; i += 2)
            screens[0][(SCREENHEIGHT - 1) * SCREENWIDTH + i] = 0x0;
    }

    src = screens[0];
    for (i = 0; i < SCREENWIDTH * SCREENHEIGHT; i++)
        pixels[i] = pal32[src[i]];

    hdc = GetDC(hwnd);
    Present(hdc);
    ReleaseDC(hwnd, hdc);
}

void I_ReadScreen(byte* scr)
{
    memcpy(scr, screens[0], SCREENWIDTH * SCREENHEIGHT);
}

void I_SetPalette(byte* palette)
{
    int i;

    for (i = 0; i < 256; i++)
    {
        unsigned int r = gammatable[usegamma][*palette++];
        unsigned int g = gammatable[usegamma][*palette++];
        unsigned int b = gammatable[usegamma][*palette++];
        pal32[i] = (r << 16) | (g << 8) | b;
    }
}

void I_InitGraphics(void)
{
    static int firsttime = 1;
    WNDCLASSA  wc;
    RECT       r;
    DWORD      style = WS_OVERLAPPEDWINDOW;

    if (!firsttime)
        return;
    firsttime = 0;

    SetProcessDPIAware();
    hinst = GetModuleHandle(NULL);

    if (M_CheckParm("-2")) scale = 2;
    if (M_CheckParm("-3")) scale = 3;
    if (M_CheckParm("-4")) scale = 4;
    wantfullscreen = M_CheckParm("-fullscreen") != 0;

    pixels = (unsigned int*)malloc(SCREENWIDTH * SCREENHEIGHT * sizeof(unsigned int));
    memset(pixels, 0, SCREENWIDTH * SCREENHEIGHT * sizeof(unsigned int));

    memset(&bmi, 0, sizeof(bmi));
    bmi.bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth       = SCREENWIDTH;
    bmi.bmiHeader.biHeight      = -SCREENHEIGHT;        // top-down
    bmi.bmiHeader.biPlanes      = 1;
    bmi.bmiHeader.biBitCount    = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hinst;
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.lpszClassName = WINDOW_CLASS;
    if (!RegisterClassA(&wc))
        I_Error("I_InitGraphics: RegisterClass failed");

    r.left = 0; r.top = 0;
    r.right = SCREENWIDTH * scale;
    r.bottom = SCREENWIDTH * scale * ASPECT_H / ASPECT_W;
    AdjustWindowRect(&r, style, FALSE);

    hwnd = CreateWindowA(WINDOW_CLASS, "DOOM", style,
                         CW_USEDEFAULT, CW_USEDEFAULT,
                         r.right - r.left, r.bottom - r.top,
                         NULL, NULL, hinst, NULL);
    if (!hwnd)
        I_Error("I_InitGraphics: CreateWindow failed");

    ShowWindow(hwnd, SW_SHOW);
    SetForegroundWindow(hwnd);
    window_active = 1;

    if (wantfullscreen)
        ToggleFullscreen();
}
